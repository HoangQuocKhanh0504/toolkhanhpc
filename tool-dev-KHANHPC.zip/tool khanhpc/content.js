chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  try {
    switch (req.type) {
      case "getHtml":
        sendResponse(document.documentElement.outerHTML);
        break;
      case "highlight":
        document.querySelectorAll("*").forEach(el => el.style.outline = "1px solid red");
        sendResponse("✅ Elements highlighted");
        break;
      case "removeModals":
        document.querySelectorAll("*").forEach(el => {
          const st = getComputedStyle(el);
          if (["fixed", "sticky"].includes(st.position)) el.remove();
        });
        sendResponse("✅ Modals removed");
        break;
      case "getCookies":
        sendResponse(document.cookie);
        break;
      case "getStorage":
        sendResponse(JSON.stringify({
          localStorage: {...localStorage},
          sessionStorage: {...sessionStorage}
        }, null, 2));
        break;
      case "autoScroll":
        const duration = req.seconds || 3;
        const interval = setInterval(() => window.scrollBy(0, 100), 100);
        setTimeout(() => clearInterval(interval), duration * 1000);
        sendResponse(`🌀 Cuộn trong ${duration} giây`);
        break;
      case "extractLinks":
        const links = Array.from(document.querySelectorAll("a")).map(a => a.href);
        sendResponse(JSON.stringify([...new Set(links)], null, 2));
        break;
      case "wordCount":
        const wc = document.body.innerText.trim().split(/\s+/).length;
        sendResponse("🔢 Số từ: " + wc);
        break;
        case "removeCss":
  document.querySelectorAll("link[rel=stylesheet], style").forEach(el => el.remove());
  sendResponse("🧽 Đã xoá toàn bộ CSS");
  break;
case "enableEdit":
  document.body.contentEditable = true;
  document.designMode = "on";
  sendResponse("✏️ Trang đã có thể chỉnh sửa");
  break;

      default:
        sendResponse(`❌ Không rõ: ${req.type}`);
    }
  } catch (e) {
    sendResponse(`❌ Lỗi: ${e.message}`);
  }
  return true;
});
