let currentTab;

document.addEventListener("DOMContentLoaded", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab;

  const favicon = document.getElementById("favicon");
  const title = document.getElementById("title");
  const urlText = document.getElementById("url");

  const faviconUrl = `https://www.google.com/s2/favicons?domain_url=${tab.url}`;
  favicon.src = faviconUrl;

  // Nếu favicon không load được → dùng GD.png
  favicon.onerror = () => {
    favicon.src = "GD.png";
  };

  title.textContent = tab.title;
  urlText.textContent = tab.url;

  // Gán sự kiện click cho các nút công cụ
  document.querySelectorAll("button[data-tool]").forEach(btn =>
    btn.addEventListener("click", () => handleTool(btn.dataset.tool))
  );

  // Pin popup
  const pinBtn = document.getElementById("pinPopup");
  if (pinBtn) {
    pinBtn.addEventListener("click", () => {
      chrome.windows.create({
        url: chrome.runtime.getURL("popup.html"),
        type: "popup",
        width: 400,
        height: 600
      });
    });
  }

  // Dark mode toggle
  const toggle = document.getElementById("darkModeToggle");
  const isDark = localStorage.getItem("darkMode") === "true";

  if (isDark) {
    document.body.classList.add("dark");
    if (toggle) toggle.checked = true;
  }

  if (toggle) {
    toggle.addEventListener("change", () => {
      const enableDark = toggle.checked;
      document.body.classList.toggle("dark", enableDark);
      localStorage.setItem("darkMode", enableDark);
    });
  }
});

function handleTool(tool) {
  const output = document.getElementById("output");
  output.textContent = "⏳ Đang xử lý...";

  const scrollTime = parseInt(document.getElementById("scrollTime")?.value || "3");

  const sendTool = (type) => {
    chrome.tabs.sendMessage(currentTab.id, { type, seconds: scrollTime }, res => {
      if (chrome.runtime.lastError) {
        output.textContent = "❌ " + chrome.runtime.lastError.message;
      } else {
        output.textContent = res;
      }
    });
  };

  if ([
    "getHtml", "highlight", "removeModals", "getCookies", "getStorage",
    "autoScroll", "extractLinks", "wordCount", "removeCss", "enableEdit"
  ].includes(tool)) {
    sendTool(tool);
  } else {
    switch (tool) {
      case "copyHtml":
        chrome.tabs.sendMessage(currentTab.id, { type: "getHtml" }, html => {
          navigator.clipboard.writeText(html);
          output.textContent = "✅ HTML copied";
        });
        break;
      case "copyUrl":
        navigator.clipboard.writeText(currentTab.url);
        output.textContent = "✅ URL copied";
        break;
      case "shortenUrl":
        fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(currentTab.url)}`)
          .then(r => r.text()).then(u => output.textContent = "🔗 " + u)
          .catch(e => output.textContent = "❌ " + e.message);
        break;
      case "reload":
        chrome.tabs.reload(currentTab.id);
        output.textContent = "🔁 Reloaded";
        break;
      default:
        output.textContent = "❌ Tool không hỗ trợ.";
    }
  }
}
