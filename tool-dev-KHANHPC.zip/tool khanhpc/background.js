chrome.runtime.onInstalled.addListener(() => {
  console.log("✅ Web Tools Pro Deluxe – extension installed.");
});
